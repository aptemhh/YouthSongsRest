
-- --------------------------------------------------------

--
-- Структура таблицы PARTY_SONGS
--

CREATE TABLE PARTY_SONGS (
  song_id int(11) NOT NULL,
  party_id int(11) NOT NULL,
  position int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы PARTY_SONGS
--

INSERT INTO PARTY_SONGS (song_id, party_id, `position`) VALUES
(33, 1, 0),
(109, 1, 1),
(119, 1, 2);
