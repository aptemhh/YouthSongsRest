
--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы PARTY
--
ALTER TABLE PARTY
  ADD PRIMARY KEY (id),
  ADD UNIQUE KEY PARTY_NAME_INDEX (name);

--
-- Индексы таблицы PARTY_SONGS
--
ALTER TABLE PARTY_SONGS
  ADD PRIMARY KEY (song_id,party_id,position),
  ADD KEY PARTY_SONGS_GROUP_ID_FK (party_id);

--
-- Индексы таблицы SONG
--
ALTER TABLE SONG
  ADD PRIMARY KEY (ID);

--
-- Индексы таблицы statistic
--
ALTER TABLE statistic
  ADD PRIMARY KEY (id);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы PARTY
--
ALTER TABLE PARTY
  MODIFY id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы statistic
--
ALTER TABLE statistic
  MODIFY id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы PARTY_SONGS
--
ALTER TABLE PARTY_SONGS
  ADD CONSTRAINT PARTY_SONGS_GROUP_ID_FK FOREIGN KEY (party_id) REFERENCES PARTY (id) ON DELETE CASCADE,
  ADD CONSTRAINT PARTY_SONGS_SONG_ID_FK FOREIGN KEY (song_id) REFERENCES SONG (ID) ON DELETE CASCADE;
