
-- --------------------------------------------------------

--
-- Структура таблицы statistic
--

CREATE TABLE statistic (
  id int(11) NOT NULL,
  number int(11) NOT NULL,
  date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
