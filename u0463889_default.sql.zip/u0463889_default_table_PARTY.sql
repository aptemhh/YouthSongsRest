
-- --------------------------------------------------------

--
-- Структура таблицы PARTY
--

CREATE TABLE PARTY (
  id int(11) NOT NULL,
  name varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы PARTY
--

INSERT INTO PARTY (id, `name`) VALUES
(1, 'nameParty');
